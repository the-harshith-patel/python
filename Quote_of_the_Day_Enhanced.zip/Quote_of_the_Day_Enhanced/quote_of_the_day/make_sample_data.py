"""Generates data/sample_quotes.json, sample_quotes.csv, mock_cache.json and legacy_import_sample.csv."""
import csv, json, random
from datetime import date, timedelta
from pathlib import Path

D = Path(__file__).resolve().parent / "data"
D.mkdir(exist_ok=True)
random.seed(7)

BASE = [
 ("The only way to do great work is to love what you do.", "Steve Jobs", "motivation"),
 ("Whether you think you can, or you think you can't, you're right.", "Henry Ford", "motivation"),
 ("It always seems impossible until it's done.", "Nelson Mandela", "motivation"),
 ("Well done is better than well said.", "Benjamin Franklin", "wisdom"),
 ("The unexamined life is not worth living.", "Socrates", "wisdom"),
 ("Knowing yourself is the beginning of all wisdom.", "Aristotle", "wisdom"),
 ("He who has a why to live can bear almost any how.", "Friedrich Nietzsche", "wisdom"),
 ("Life is what happens when you're busy making other plans.", "John Lennon", "life"),
 ("In the middle of difficulty lies opportunity.", "Albert Einstein", "life"),
 ("Life is really simple, but we insist on making it complicated.", "Confucius", "life"),
 ("The journey of a thousand miles begins with a single step.", "Lao Tzu", "life"),
 ("Success is not final, failure is not fatal: courage to continue counts.", "Winston Churchill", "success"),
 ("Success usually comes to those who are too busy to be looking for it.", "Henry David Thoreau", "success"),
 ("I have not failed. I've just found 10,000 ways that won't work.", "Thomas Edison", "success"),
 ("Genius is one percent inspiration and ninety-nine percent perspiration.", "Thomas Edison", "success"),
 ("I am so clever that sometimes I don't understand a single word of what I am saying.", "Oscar Wilde", "humor"),
 ("Always forgive your enemies; nothing annoys them so much.", "Oscar Wilde", "humor"),
 ("I can resist everything except temptation.", "Oscar Wilde", "humor"),
 ("Get your facts first, then you can distort them as you please.", "Mark Twain", "humor"),
 ("The secret of getting ahead is getting started.", "Mark Twain", "motivation"),
 ("To love and be loved is to feel the sun from both sides.", "David Viscott", "love"),
 ("Love all, trust a few, do wrong to none.", "William Shakespeare", "love"),
 ("Where there is love there is life.", "Mahatma Gandhi", "love"),
 ("Be the change that you wish to see in the world.", "Mahatma Gandhi", "wisdom"),
 ("What we think, we become.", "Buddha", "wisdom"),
 ("Do what you can, with what you have, where you are.", "Theodore Roosevelt", "motivation"),
 ("Believe you can and you're halfway there.", "Theodore Roosevelt", "motivation"),
 ("Happiness depends upon ourselves.", "Aristotle", "life"),
 ("Fall seven times, stand up eight.", "Japanese Proverb", "motivation"),
 ("Simplicity is the ultimate sophistication.", "Leonardo da Vinci", "wisdom"),
 ("An investment in knowledge pays the best interest.", "Benjamin Franklin", "success"),
 ("Quality is not an act, it is a habit.", "Will Durant", "success"),
 ("Nothing in life is to be feared, it is only to be understood.", "Marie Curie", "life"),
 ("Imagination is more important than knowledge.", "Albert Einstein", "wisdom"),
 ("The best way to predict the future is to create it.", "Peter Drucker", "success"),
 ("Do not go where the path may lead; go instead where there is no path.", "Ralph Waldo Emerson", "motivation"),
 ("Silence is a true friend who never betrays.", "Confucius", "wisdom"),
 ("Time is what we want most, but what we use worst.", "William Penn", "life"),
 ("A smooth sea never made a skilled sailor.", "Franklin D. Roosevelt", "life"),
]

rows, today = [], date.today()
for i, (t, a, c) in enumerate(BASE, start=1):
    rows.append({"id": i, "text": t, "author": a, "category": c,
                 "rating": random.choice([3, 4, 4, 5, 5, 2]),
                 "date_added": (today - timedelta(days=random.randint(0, 150))).isoformat(),
                 "source": random.choice(["api", "manual", "manual"])})

# Edge / boundary cases
n = len(rows)
rows.append({"id": n+1, "text": "Fortune favours the bold.", "author": "Unknown", "category": "other",
             "rating": 1, "date_added": today.isoformat(), "source": "manual"})            # missing author + min rating
rows.append({"id": n+2, "text": "Well done is better than well said.", "author": "Benjamin Franklin",
             "category": "wisdom", "rating": 5, "date_added": today.isoformat(), "source": "manual"})  # duplicate
rows.append({"id": n+3, "text": ("Patience is bitter, but its fruit is sweet. " * 6).strip(), "author": "Aristotle",
             "category": "wisdom", "rating": 3, "date_added": today.isoformat(), "source": "manual"})  # anomalous length
rows.append({"id": n+4, "text": "Less is more.", "author": "Ludwig Mies van der Rohe", "category": "wisdom",
             "rating": 5, "date_added": today.isoformat(), "source": "manual"})           # short + max rating
rows.sort(key=lambda r: r["id"])

(D / "sample_quotes.json").write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")
with open(D / "sample_quotes.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
(D / "mock_cache.json").write_text(json.dumps(
    [{"text": t, "author": a} for t, a, _ in random.sample(BASE, 12)], indent=2, ensure_ascii=False), encoding="utf-8")

legacy = [
 ["text", "author", "category", "rating"],
 ["Courage is grace under pressure.", "Ernest Hemingway", "motivation", "4"],
 ["Stay hungry, stay foolish.", "Steve Jobs", "motivation", "5"],
 ["", "Nobody", "life", "3"],                                  # blank text
 ["Action is the foundational key to all success.", "Pablo Picasso", "success", "9"],   # rating out of range
 ["Dream big and dare to fail.", "Norman Vaughan", "cooking", "4"],                     # bad category
 ["Every moment is a fresh beginning.", "T. S. Eliot", "life", "abc"],                  # non-numeric rating
 ["Courage is grace under pressure.", "Ernest Hemingway", "motivation", "4"],           # duplicate
 ["The harder I work, the luckier I get.", "Gary Player", "success", "4"],
]
with open(D / "legacy_import_sample.csv", "w", newline="", encoding="utf-8") as f:
    csv.writer(f).writerows(legacy)
print("sample data written:", len(rows), "records")
