"""Summary metrics, trends and warning indicators."""
from collections import Counter

LONG_QUOTE = 250


def summarize(quotes):
    if not quotes:
        return None
    n = len(quotes)
    ratings = [q["rating"] for q in quotes]
    lengths = [len(q["text"]) for q in quotes]
    by_cat = Counter(q["category"] for q in quotes)
    by_author = Counter(q["author"] for q in quotes if q["author"] != "Unknown")
    by_month = Counter(q["date_added"][:7] for q in quotes)
    by_source = Counter(q["source"] for q in quotes)
    top = max(quotes, key=lambda q: (q["rating"], -q["id"]))
    return {
        "total": n,
        "avg_rating": sum(ratings) / n,
        "avg_length": sum(lengths) / n,
        "by_category": dict(by_cat.most_common()),
        "top_authors": by_author.most_common(5),
        "by_month": dict(sorted(by_month.items())),
        "by_source": dict(by_source),
        "rating_dist": {r: ratings.count(r) for r in range(1, 6)},
        "top_quote": top,
        "status": status_label(sum(ratings) / n),
    }


def status_label(avg):
    if avg >= 4:
        return "EXCELLENT collection"
    if avg >= 3:
        return "GOOD collection"
    return "NEEDS CURATION"


def warnings(quotes):
    """Threshold warning indicators."""
    out, seen = [], {}
    for q in quotes:
        key = q["text"].strip().lower()
        if key in seen:
            out.append(f"Duplicate: #{q['id']} repeats #{seen[key]}")
        else:
            seen[key] = q["id"]
        if len(q["text"]) > LONG_QUOTE:
            out.append(f"Anomalous length: #{q['id']} has {len(q['text'])} characters")
        if q["rating"] == 1:
            out.append(f"Low rating: #{q['id']} is rated 1/5 - consider removing")
        if q["author"] == "Unknown":
            out.append(f"Missing author: #{q['id']}")
    return out


def search(quotes, keyword="", category=""):
    kw = keyword.strip().lower()
    cat = category.strip().lower()
    return [
        q for q in quotes
        if (not kw or kw in q["text"].lower() or kw in q["author"].lower())
        and (not cat or q["category"] == cat)
    ]
