"""Defensive input validation: wrappers loop until the value is valid."""
import re

CATEGORIES = ["motivation", "wisdom", "life", "success", "humor", "love", "other"]
MAX_QUOTE_LEN = 500
MAX_AUTHOR_LEN = 60


def clean_text(s):
    """Collapse whitespace and strip control characters."""
    s = re.sub(r"[\x00-\x1f\x7f]", " ", str(s))
    return re.sub(r"\s+", " ", s).strip()


def ask_text(prompt, min_len=1, max_len=MAX_QUOTE_LEN, allow_blank=False, default=None):
    while True:
        raw = clean_text(input(prompt))
        if not raw:
            if default is not None:
                return default
            if allow_blank:
                return ""
            print("  ! Input cannot be blank.")
            continue
        if len(raw) < min_len:
            print(f"  ! Too short (minimum {min_len} characters).")
        elif len(raw) > max_len:
            print(f"  ! Too long ({len(raw)} chars, maximum {max_len}).")
        else:
            return raw


def ask_int(prompt, lo, hi, default=None):
    while True:
        raw = input(prompt).strip()
        if not raw and default is not None:
            return default
        try:
            value = int(raw)
        except ValueError:
            print("  ! Please enter a whole number.")
            continue
        if lo <= value <= hi:
            return value
        print(f"  ! Number must be between {lo} and {hi}.")


def ask_category(prompt="Category", default="other"):
    options = ", ".join(CATEGORIES)
    while True:
        raw = clean_text(input(f"{prompt} [{options}] (Enter = {default}): ")).lower()
        if not raw:
            return default
        if raw in CATEGORIES:
            return raw
        print("  ! Unknown category. Choose one from the list.")


def ask_yes_no(prompt, default=False):
    hint = "Y/n" if default else "y/N"
    while True:
        raw = input(f"{prompt} ({hint}): ").strip().lower()
        if not raw:
            return default
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        print("  ! Please answer y or n.")


def validate_record(data):
    """Validate a dict (e.g. a CSV row). Returns (clean_record, [errors])."""
    errors = []
    text = clean_text(data.get("text", ""))
    author = clean_text(data.get("author", "")) or "Unknown"
    category = clean_text(data.get("category", "")).lower() or "other"
    rating_raw = str(data.get("rating", "")).strip() or "3"

    if not text:
        errors.append("quote text is empty")
    elif len(text) > MAX_QUOTE_LEN:
        errors.append(f"quote text too long ({len(text)} > {MAX_QUOTE_LEN})")
    if len(author) > MAX_AUTHOR_LEN:
        errors.append("author name too long")
    if category not in CATEGORIES:
        errors.append(f"unknown category '{category}'")
    try:
        rating = int(rating_raw)
        if not 1 <= rating <= 5:
            errors.append(f"rating {rating} outside 1-5")
    except ValueError:
        rating = 3
        errors.append(f"rating '{rating_raw}' is not a number")

    return {"text": text, "author": author, "category": category, "rating": rating}, errors
