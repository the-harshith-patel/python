# Quote of the Day — Streamlit Edition

## Run on Windows (VS Code)

1. Open this folder in VS Code.
2. Open Terminal → New Terminal.
3. Install the packages:

   ```powershell
   py -m pip install -r requirements_streamlit.txt
   ```

4. Start the app:

   ```powershell
   py -m streamlit run streamlit_app.py
   ```

5. Streamlit opens the app in your browser at `http://localhost:8501`.

## First launch

If your saved quote collection is empty, the app loads the included 43-quote sample dataset once so the dashboard, charts and report exports have data to demonstrate. Existing saved quotes are never replaced.

## Main features

- Dashboard with collection metrics, charts, top authors and data-quality warnings
- Fetch today's quote from ZenQuotes (uses a local cache if the API is unavailable)
- Add, browse, search, sort and delete quotes
- Category and rating analytics
- Generate downloadable category, rating and monthly-trend chart images
- Export a Markdown summary, TXT audit log and CSV quote report
- Import quotes from a CSV file with row validation

Reports are generated from the saved quote collection. Use **Export Reports** or **Charts** in the sidebar.
