"""Quote of the Day - Streamlit GUI.

A web front-end for the terminal app. It does NOT duplicate any logic: every feature calls the
existing modules (storage, validation, analytics, api, export, plotting), so the GUI and the
terminal menu always agree and share the same data/quotes.json.

Run:  streamlit run streamlit_app.py
"""
import shutil
import tempfile
from pathlib import Path

import pandas as pd
import streamlit as st

import analytics
import api
import export
import plotting
import storage
import validation as v

LEGACY_SAMPLE = storage.DATA_DIR / "legacy_import_sample.csv"
PAGES = [
    "Dashboard",
    "Today's Quote",
    "Add Quote",
    "Browse & Search",
    "Charts",
    "Export Reports",
    "Bulk Import",
    "Sample Data",
]
ICONS = {"Dashboard": "📊", "Today's Quote": "🌅", "Add Quote": "➕", "Browse & Search": "🔎",
         "Charts": "📈", "Export Reports": "📤", "Bulk Import": "📥", "Sample Data": "🧪"}

st.set_page_config(page_title="Quote of the Day", page_icon="💬", layout="wide")

st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800&family=Playfair+Display:ital,wght@0,600;1,600&display=swap');
    :root { --ink:#17251f; --muted:#738078; --green:#176b50; --mint:#e9f5ef; }
    .stApp { background: linear-gradient(145deg,#f6faf7 0%,#eef5f0 55%,#f8faf8 100%); }
    html, body, [class*="css"] { font-family:'DM Sans',sans-serif; }
    .block-container {padding-top: 1.6rem; padding-bottom:3rem; max-width: 1320px;}
    [data-testid="stSidebar"] {background:linear-gradient(180deg,#102d25,#174b3b); }
    [data-testid="stSidebar"] * {color:#f2fbf6 !important;}
    [data-testid="stSidebar"] [data-testid="stMetric"] {background:#245a47;border:1px solid #39745e;}
    .hero {background:linear-gradient(120deg,#123c30 0%,#176b50 58%,#56a77e 100%);
           color:#fff;padding:2rem 2.2rem;border-radius:22px;margin-bottom:1.35rem;
           box-shadow:0 14px 35px rgba(20,75,54,.16);position:relative;overflow:hidden;}
    .hero:after {content:'✦';position:absolute;right:35px;top:-35px;font-size:150px;color:rgba(255,255,255,.10);}
    .hero h1 {margin:0;font-size:2.15rem;color:#fff;font-weight:800;letter-spacing:-.8px;}
    .hero p {margin:.45rem 0 0;color:#e0f2e8;font-size:1rem;}
    .qcard {border:1px solid #d7e8dc;border-left:6px solid #23845f;
            background:linear-gradient(120deg,#fff,#f2faf5);padding:1.65rem 1.8rem;
            border-radius:18px;margin:.7rem 0 1.3rem;box-shadow:0 8px 24px rgba(29,83,57,.07);}
    .qcard .qt {font-family:'Playfair Display',serif;font-size:1.65rem;font-style:italic;
                line-height:1.5;color:#203b2e;}
    .qcard .qa {margin-top:.8rem;font-weight:700;color:#287452;}
    div[data-testid="stMetric"] {background:#fff;border:1px solid #deebe1;border-radius:16px;
        padding:1rem 1.1rem;box-shadow:0 5px 18px rgba(27,75,52,.045);}
    div[data-testid="stMetricLabel"] {color:#718078;font-weight:600;}
    div[data-testid="stMetricValue"] {color:#174b38;font-weight:800;}
    .stButton>button, .stDownloadButton>button {border-radius:11px;font-weight:700;
        border:1px solid #c9dfd1;transition:all .2s ease;}
    .stButton>button[kind="primary"] {background:linear-gradient(100deg,#176b50,#29966b);border:0;}
    div[data-testid="stDataFrame"], div[data-testid="stChart"] {background:#fff;border-radius:15px;padding:.5rem;}
    hr {border-color:#dce9df;}
    h1,h2,h3 {color:#183c2e;}
    </style>
    """,
    unsafe_allow_html=True,
)


# ---------- helpers ----------
def to_df(quotes):
    cols = ["id", "text", "author", "category", "rating", "date_added", "source"]
    return pd.DataFrame(quotes, columns=cols)


def stars(n):
    return "★" * int(n) + "☆" * (5 - int(n))


def quote_card(text, author, meta=""):
    st.markdown(
        f'<div class="qcard"><div class="qt">“{text}”</div>'
        f'<div class="qa">— {author}</div>'
        f'<div style="opacity:.7;margin-top:.3rem">{meta}</div></div>',
        unsafe_allow_html=True,
    )


def hero(title, subtitle):
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def flash():
    """Show a one-shot message saved before st.rerun()."""
    msg = st.session_state.pop("flash", None)
    if msg:
        kind, text = msg
        getattr(st, kind)(text)


def set_flash(kind, text):
    st.session_state["flash"] = (kind, text)


# ---------- pages ----------
def page_dashboard(quotes):
    hero("Your Quote Library", "A thoughtful space to collect ideas, track favourites and explore your inspiration")
    st.caption("COLLECTION OVERVIEW  ·  " + __import__("datetime").date.today().strftime("%A, %d %B %Y"))
    s = analytics.summarize(quotes)
    if not s:
        st.info("No data yet. Add a quote or load the sample dataset from the **Sample Data** page.")
        return

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total quotes", s["total"])
    c2.metric("Average rating", f"{s['avg_rating']:.2f} / 5")
    c3.metric("Average length", f"{s['avg_length']:.0f} chars")
    c4.metric("Status", s["status"])

    left, right = st.columns(2)
    with left:
        st.subheader("By category")
        st.bar_chart(pd.Series(s["by_category"], name="quotes"), color="#2e8b57")
    with right:
        st.subheader("Rating distribution")
        st.bar_chart(pd.Series({f"{k}★": n for k, n in s["rating_dist"].items()}, name="quotes"),
                     color="#e0a800")

    left, right = st.columns(2)
    with left:
        st.subheader("Monthly trend")
        st.line_chart(pd.Series(s["by_month"], name="quotes saved"), color="#1f77b4")
    with right:
        st.subheader("Top authors")
        if s["top_authors"]:
            st.dataframe(pd.DataFrame(s["top_authors"], columns=["Author", "Quotes"]),
                         hide_index=True, use_container_width=True)
        else:
            st.caption("No named authors yet.")

    st.subheader("Top rated quote")
    t = s["top_quote"]
    quote_card(t["text"], t["author"], f"{stars(t['rating'])}  ·  {t['category']}")

    warns = analytics.warnings(quotes)
    st.subheader(f"Warnings ({len(warns)})")
    if warns:
        with st.expander("Show threshold warnings", expanded=len(warns) <= 6):
            for w in warns:
                st.warning(w)
    else:
        st.success("No warnings - the collection looks clean.")


def page_today(quotes):
    hero("Today's Quote", "Fetched from ZenQuotes - falls back to the local cache when offline")
    flash()
    if st.button("Fetch quote of the day", type="primary"):
        with st.spinner("Fetching..."):
            q, origin = api.fetch_quote()
        st.session_state["fetched"] = (q, origin)

    fetched = st.session_state.get("fetched")
    if not fetched:
        st.caption("Press the button to fetch a quote.")
        return
    q, origin = fetched
    if origin == "cache":
        st.warning("Offline or API unavailable - using local mock cache.")
    else:
        st.success("Fetched live from the API.")
    quote_card(q["text"], q["author"], f"source: {origin}")

    if storage.is_duplicate(quotes, q["text"]):
        st.info("Already in your favourites.")
        return
    with st.form("save_fetched"):
        st.markdown("**Save to favourites**")
        c1, c2 = st.columns(2)
        cat = c1.selectbox("Category", v.CATEGORIES, index=v.CATEGORIES.index("other"))
        rating = c2.slider("Rating", 1, 5, 3)
        if st.form_submit_button("Save quote"):
            rec = storage.make_record(quotes, q["text"], q["author"], cat, rating, source=origin)
            quotes.append(rec)
            storage.save_quotes(quotes)
            st.session_state.pop("fetched", None)
            set_flash("success", f"Saved as #{rec['id']}.")
            st.rerun()


def page_add(quotes):
    hero("Add a Quote", "Every field is validated with the same rules as the terminal app")
    flash()
    with st.form("add_form", clear_on_submit=False):
        text = st.text_area("Quote text", height=110, help=f"5 to {v.MAX_QUOTE_LEN} characters")
        c1, c2, c3 = st.columns([2, 1, 1])
        author = c1.text_input("Author (blank = Unknown)")
        cat = c2.selectbox("Category", v.CATEGORIES, index=v.CATEGORIES.index("other"))
        rating = c3.slider("Rating", 1, 5, 3)
        submitted = st.form_submit_button("Save quote", type="primary")

    if not submitted:
        return
    # Reuse validate_record so GUI rules == CLI rules, then apply the same extras as add_flow
    rec, errors = v.validate_record({"text": text, "author": author, "category": cat, "rating": rating})
    if len(rec["text"]) < 5 and rec["text"]:
        errors.append("quote text too short (minimum 5 characters)")
    if rec["text"] and storage.is_duplicate(quotes, rec["text"]):
        errors.append("that quote already exists")
    if errors:
        for e in errors:
            st.error(e.capitalize())
        return
    new = storage.make_record(quotes, rec["text"], rec["author"], rec["category"], rec["rating"])
    quotes.append(new)
    storage.save_quotes(quotes)
    set_flash("success", f"Saved as #{new['id']}.")
    st.rerun()


def page_browse(quotes):
    hero("Browse & Search", "Keyword and category filters, plus delete")
    flash()
    if not quotes:
        st.info("No quotes yet.")
        return
    c1, c2, c3 = st.columns([3, 2, 2])
    kw = c1.text_input("Keyword (text or author)")
    cat = c2.selectbox("Category", ["(all)"] + v.CATEGORIES)
    sort = c3.selectbox("Sort by", ["ID", "Rating (high first)", "Author", "Date added (newest)"])

    results = analytics.search(quotes, kw, "" if cat == "(all)" else cat)
    df = to_df(results)
    if sort == "Rating (high first)":
        df = df.sort_values(["rating", "id"], ascending=[False, True])
    elif sort == "Author":
        df = df.sort_values("author", key=lambda s: s.str.lower())
    elif sort == "Date added (newest)":
        df = df.sort_values(["date_added", "id"], ascending=[False, False])
    st.caption(f"{len(df)} match(es) of {len(quotes)}")
    st.dataframe(
        df.rename(columns={"id": "ID", "text": "Quote", "author": "Author", "category": "Category",
                           "rating": "Rating", "date_added": "Added", "source": "Source"}),
        hide_index=True, use_container_width=True, height=420,
        column_config={"Rating": st.column_config.NumberColumn(format="%d ★")},
    )

    st.divider()
    st.subheader("Delete a quote")
    ids = [q["id"] for q in quotes]
    qid = st.selectbox("Quote ID", ids, format_func=lambda i: f"#{i}  -  " + next(
        q["text"][:60] for q in quotes if q["id"] == i))
    match = next(q for q in quotes if q["id"] == qid)
    quote_card(match["text"], match["author"], f"{match['category']} · {stars(match['rating'])}")
    confirm = st.checkbox("Yes, delete this quote")
    if st.button("Delete", disabled=not confirm):
        quotes.remove(match)
        storage.save_quotes(quotes)
        set_flash("success", f"Deleted #{qid}.")
        st.rerun()


def page_charts(quotes):
    hero("Charts", "Matplotlib PNGs from plotting.py, saved to the reports/ folder")
    if not analytics.summarize(quotes):
        st.info("No data to plot.")
        return
    if st.button("Generate charts", type="primary"):
        files = plotting.make_charts(quotes)
        st.session_state["chart_files"] = [str(f) for f in files]
    files = [Path(f) for f in st.session_state.get("chart_files", []) if Path(f).exists()]
    if not files:
        st.caption("Press the button to generate the category, rating and trend charts.")
        return
    cols = st.columns(len(files))
    for col, f in zip(cols, files):
        col.image(str(f), use_container_width=True)
        col.download_button(f"Download {f.name}", f.read_bytes(), file_name=f.name,
                            mime="image/png", key=f"dl_{f.name}")
    st.success("Saved: " + ", ".join(f"reports/{f.name}" for f in files))


def page_export(quotes):
    hero("Export Reports", "Markdown summary, TXT audit log and CSV of all quotes")
    if not quotes:
        st.info("Nothing to export.")
        return
    if st.button("Export all reports", type="primary"):
        st.session_state["export_files"] = [str(f) for f in export.export_all(quotes)]
    files = [Path(f) for f in st.session_state.get("export_files", []) if Path(f).exists()]
    if not files:
        st.caption("Press the button to create the reports.")
        return
    mimes = {".md": "text/markdown", ".txt": "text/plain", ".csv": "text/csv"}
    for f in files:
        c1, c2 = st.columns([4, 1])
        c1.write(f"✅ `reports/{f.name}`")
        c2.download_button("Download", f.read_bytes(), file_name=f.name,
                           mime=mimes.get(f.suffix, "application/octet-stream"), key=f"dl_{f.name}")
    md = next((f for f in files if f.suffix == ".md"), None)
    if md:
        with st.expander("Preview Markdown report"):
            st.markdown(md.read_text(encoding="utf-8"))


def page_import(quotes):
    hero("Bulk Import", "Row-by-row validation with an error log, same as the terminal importer")
    flash()
    st.write("Expected columns: `text, author, category, rating`")
    up = st.file_uploader("Upload a CSV", type=["csv"])
    c1, c2 = st.columns(2)
    run_upload = c1.button("Import uploaded file", type="primary", disabled=up is None)
    run_sample = c2.button(f"Import {LEGACY_SAMPLE.name} (demo)")

    path = None
    if run_upload and up is not None:
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".csv")
        tmp.write(up.getvalue())
        tmp.close()
        path = tmp.name
    elif run_sample:
        path = str(LEGACY_SAMPLE)
    if not path:
        return

    added, errors = storage.import_csv(path, quotes, storage.BASE_DIR / "reports" / "import_errors.log")
    storage.save_quotes(quotes)
    st.success(f"Imported {added} row(s).")
    if errors:
        st.warning(f"{len(errors)} problem(s) - logged to reports/import_errors.log")
        st.dataframe(pd.DataFrame({"Rejected rows / reasons": errors}), hide_index=True,
                     use_container_width=True)


def page_sample(quotes):
    hero("Sample Data", "Load the 43-entry demo dataset (includes edge cases)")
    flash()
    st.write("This copies `data/sample_quotes.json` over `data/quotes.json`.")
    ok = True
    if quotes:
        st.warning("This replaces your current data.")
        ok = st.checkbox("I understand - replace my data")
    if st.button("Load sample dataset", type="primary", disabled=not ok):
        shutil.copy(storage.SAMPLE_FILE, storage.QUOTES_FILE)
        n = len(storage.load_quotes())
        set_flash("success", f"Loaded {n} sample quotes.")
        st.rerun()


ROUTES = {
    "Dashboard": page_dashboard,
    "Today's Quote": page_today,
    "Add Quote": page_add,
    "Browse & Search": page_browse,
    "Charts": page_charts,
    "Export Reports": page_export,
    "Bulk Import": page_import,
    "Sample Data": page_sample,
}


def main():
    quotes = storage.load_quotes()           # always read fresh from the shared JSON file
    # First-run experience: seed the demo collection only when the user's collection is empty.
    # Existing saved quotes are never overwritten.
    if not quotes and storage.SAMPLE_FILE.exists():
        quotes = storage.load_quotes(storage.SAMPLE_FILE)
        if quotes:
            storage.save_quotes(quotes)
            st.session_state["first_run_sample_loaded"] = True
    if st.session_state.pop("first_run_sample_loaded", False):
        st.toast("Loaded 43 sample quotes to get your dashboard started.", icon="✨")
    with st.sidebar:
        st.markdown("## 💬 Quote of the Day")
        st.caption("GreenFuture Hack · Project #113")
        page = st.radio("Navigate", PAGES, format_func=lambda p: f"{ICONS[p]}  {p}",
                        label_visibility="collapsed")
        st.divider()
        st.metric("Saved quotes", len(quotes))
        st.caption("Data: data/quotes.json (shared with the terminal app)")
    ROUTES[page](quotes)


main()
